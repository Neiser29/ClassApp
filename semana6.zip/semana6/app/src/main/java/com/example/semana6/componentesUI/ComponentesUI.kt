package com.example.semana6.componentesUI

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.DismissDirection
import androidx.compose.material.DismissValue
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Surface
import androidx.compose.material.SwipeToDismiss
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.res.painterResource
import androidx.compose.material.rememberDismissState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavHostController
import com.example.semana6.logicaNegocio.Actividades
import com.example.semana6.modeloNav.ItemBarrainferior
import com.example.semana6.navegacion.ElementosNav
import com.example.semana6.navegacion.RutaActualNav
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import androidx.navigation.NavController
import com.example.semana6.Notificaction.programarNotificacion
import com.example.semana6.R
import com.example.semana6.views.ConfiguracionUI
import com.example.semana6.views.RegistrosUI
import java.util.Calendar

//Definir eleentos de barra inferior
val menuItems = listOf(ItemBarrainferior.ItemCalendario,
    ItemBarrainferior.ItemListado)



@Composable
fun NavegacionInferior(navcontrolador: NavHostController, colorBarraInferior: Color) {
    BottomAppBar(
        containerColor = colorBarraInferior
    ) {
        NavigationBar(
            containerColor = colorBarraInferior
        ) {
            menuItems.forEach { item ->
                val rutaActual = RutaActualNav(navcontrolador = navcontrolador) == item.ruta
                NavigationBarItem(
                    selected = rutaActual,
                    onClick = { navcontrolador.navigate(item.ruta) },
                    icon = {
                        Icon(
                            imageVector = item.icono,
                            contentDescription = null,
                            tint = if (rutaActual) Color(0xFFD00000) else Color.Black//Cambia el color del ícono
                        )
                    },
                    label = {
                        Text(
                            text = item.titulo,
                            color = if (rutaActual) Color(0xFFD00000) else Color.Black, //Cambia el color del texto
                            fontSize = 12.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = if (rutaActual) Color(0xFFFFE8E8) else Color.Transparent,
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CajaTextoGenerica(texto: String, label: String, onvalue: (String) -> Unit, icon: @Composable (() -> Unit)? = null) {
    OutlinedTextField(
        value = texto,
        label = {Text(text = label)},
        onValueChange = onvalue,
        modifier = Modifier
            .width(310.dp)
            .padding(top = 1.dp),
        leadingIcon = icon,
        keyboardOptions = KeyboardOptions.Default.copy(
            capitalization = KeyboardCapitalization.Sentences
        ),
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedBorderColor = Color.Gray,
            unfocusedBorderColor = Color.LightGray,
            cursorColor = Color.LightGray,
            focusedLabelColor = Color.Gray,
            unfocusedLabelColor = Color.Gray
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CajaTextoGenericaFechaHora(
    texto: String,
    label: String,
    onValueChange: (String) -> Unit,
    isDateField: Boolean = false,
    isError: Boolean = false,
    icon: @Composable (() -> Unit)? = null
) {
    val contexto = LocalContext.current
    val calendar = remember { Calendar.getInstance() }

    OutlinedTextField(
        value = texto,
        label = { Text(text = label) },
        isError = isError,
        onValueChange = { input -> onValueChange(input) },
        modifier = Modifier
            .padding(top = 1.dp)
            .width(310.dp),
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedBorderColor = Color.Gray,
            unfocusedBorderColor = Color.LightGray,
            cursorColor = Color.LightGray,
            focusedLabelColor = Color.Gray,
            unfocusedLabelColor = Color.Gray
        ),
        readOnly = true, // Hacemos que el campo solo sea editable mediante el picker
        leadingIcon = {
            if (isDateField) {
                IconButton(onClick = {
                    val datePickerDialog = DatePickerDialog(contexto, { _, year, month, dayOfMonth ->
                        val formattedDate = "${dayOfMonth.toString().padStart(2, '0')}/" +
                                "${(month + 1).toString().padStart(2, '0')}/" +
                                "$year"
                        onValueChange(formattedDate)
                    }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
                    datePickerDialog.show()
                }) {
                    Icon(Icons.Outlined.DateRange, contentDescription = "Seleccionar Fecha")
                }
            } else {
                IconButton(onClick = {
                    val timePickerDialog = TimePickerDialog(contexto, { _, hourOfDay, minute ->
                        val period = if (hourOfDay < 12) "AM" else "PM"
                        val formattedHour = if (hourOfDay > 12) hourOfDay - 12 else hourOfDay
                        val formattedMinute = minute.toString().padStart(2, '0')
                        onValueChange("${formattedHour}:${formattedMinute} $period")
                    }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false)
                    timePickerDialog.show()
                }) {
                    Icon(Icons.Outlined.AccessTime, contentDescription = "Seleccionar Hora")
                }
            }
        }
    )
}



fun isValidDate(dateStr: String): Boolean {
    return try {
        // Se permite que el mes o día sea de un solo dígito
        val formatter = DateTimeFormatter.ofPattern("d/M/yyyy") // Sin ceros a la izquierda
        val date = LocalDate.parse(dateStr, formatter)
        date.isEqual(LocalDate.now()) || date.isAfter(LocalDate.now())
    } catch (e: DateTimeParseException) {
        false
    }
}

fun isValidTime(timeStr: String): Boolean {
    // Se ajusta la expresión regular para aceptar un solo dígito en la hora
    val regex = """^(0?[1-9]|1[0-2]):([0-5]?[0-9]) (AM|PM)$""".toRegex()
    return regex.matches(timeStr)
}

fun isValidDateTime(dateStr: String, timeStr: String): Boolean {
    if (!isValidDate(dateStr)) {
        return false // Fecha no válida
    }

    if (!isValidTime(timeStr)) {
        return false // Hora no válida
    }

    // Comprobamos si la fecha es igual a hoy
    val currentDate = LocalDate.now()
    val inputDate = LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-M-d"))

    if (inputDate.isEqual(currentDate)) {
        // Si la fecha es hoy, verificamos que la hora sea actual o pasada
        val currentTime = LocalDateTime.now()
        val timeFormatter = DateTimeFormatter.ofPattern("yyyy-M-d hh:mm a")

        // Convertimos el timeStr a LocalDateTime
        val inputTime = LocalDateTime.parse("${currentDate} $timeStr", timeFormatter)

        return !inputTime.isAfter(currentTime) // La hora debe ser igual o anterior a la hora actual
    }

    return true // Si la fecha es futura, es válida
}
@Composable
fun BotonGenerico(texto: String, onclick: () -> Unit) {
    Button(
        onClick = onclick,
        modifier = Modifier
            .padding(top = 7.2.dp)
            .width(310.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFFE32D2D),
            contentColor = Color.White
        )
    ) {
        Text(text = texto)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBarra(titulo: String, colorBarra: Color, navController: NavController) {
    var showModal by remember { mutableStateOf(false) }

    TopAppBar(
        title = {
            Text(
                text = titulo,
                modifier = Modifier
                    .fillMaxWidth(),
                textAlign = TextAlign.Start,
                fontSize = 25.sp,
                color = Color.Red,fontWeight = FontWeight.SemiBold,
            )
        },
        actions = {
            IconButton(onClick = { showModal = true }) {  // Abre el ModalBottomSheet
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Icon",
                    tint = Color.Red
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = colorBarra
        )
    )

    if (showModal) {
        ModalBottomSheet(
            onDismissRequest = { showModal = false }, modifier = Modifier.fillMaxHeight(1f)
        ) {
            RegistrosUI(navcontrolador = navController)
        }
    }
}


//Boton FLotante ede Accion

@Composable
fun BotonFlotante(onclick: () -> Unit){
    FloatingActionButton(onClick=  onclick) {
        Icon(imageVector = Icons.Default.Add, contentDescription = null)
    }
}

@Composable
fun IconButtonGenerico(onclick: () -> Unit, icono: ImageVector) {
    IconButton(onClick = { onclick() }) {
        Icon(imageVector = icono, contentDescription = icono.name, tint = Color.Black)
    }
}

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun ItemActividades(actividad: Actividades, onEditar: (String, Actividades) -> Unit, onEliminar: () -> Unit
) {
    var mostrarDialogo by remember { mutableStateOf(false) }
    var mostrandoEditar by remember { mutableStateOf(false) }
    val dismissState = rememberDismissState(
        confirmStateChange = {
            if (it == DismissValue.DismissedToStart || it == DismissValue.DismissedToEnd) {
                onEliminar() }
            false }
    )
    SwipeToDismiss(
        state = dismissState,
        background = {
            val color = when (dismissState.dismissDirection) {
                DismissDirection.StartToEnd -> Color.LightGray
                DismissDirection.EndToStart -> Color.LightGray
                null -> Color.Transparent }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(5.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color)
                    .padding(8.dp),
                contentAlignment = if (dismissState.dismissDirection == DismissDirection.StartToEnd) {
                    Alignment.CenterStart
                } else { Alignment.CenterEnd }
            ) { Icon(
                    imageVector = Icons.Outlined.Delete,
                    contentDescription = null,
                    tint = Color.White)
            }
        },
        dismissContent = {
            Card(modifier = Modifier
                .fillMaxWidth()
                .padding(top = 5.dp, start = 3.dp, end = 3.dp, bottom = 4.dp)
                .clickable { mostrarDialogo = true }
                .shadow(elevation = 8.dp, shape = RoundedCornerShape(10.dp))
                .border(
                    0.5.dp, Color(
                        0xFFEBEBEB
                    ), RoundedCornerShape(10.dp)
                )
            ) { Box(modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                ) { Column (modifier = Modifier.padding(12.dp)){
                        Text(text = "${actividad.curso}", color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text(text = "${actividad.descripcion}", color = Color(0xFF7A7A7A), fontSize = 14.sp)
                    }
                }
            }
        }
    )
    if (mostrarDialogo) {
        Dialog(onDismissRequest = { mostrarDialogo = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(1f)
                    .height(450.dp),
                shape = RoundedCornerShape(16.dp),
                color = Color.White
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(onClick = { mostrarDialogo = false }) {
                            Icon(imageVector = Icons.Default.Close,
                                contentDescription = "Cerrar",
                                tint = Color.Black
                            )
                        }
                    }
                    Column(modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (!mostrandoEditar) {
                            Text(text = "${actividad.fechaentrega}  ${actividad.horaentrega}",
                                fontSize = 13.sp,
                                color = Color.Black,
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .padding(bottom = 34.dp))
                            Text(text = "${actividad.descripcion}",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Image(painter = painterResource(id = R.drawable.tarea),
                                contentDescription = "Imagen de actividad",
                                modifier = Modifier
                                    .size(115.dp)
                                    .padding(vertical = 16.dp))

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(text = "${actividad.curso}",
                                color = Color.Black,
                                modifier = Modifier.padding(bottom = 35.dp),
                                fontSize = 16.sp)
                            Text(text = "- - - - -   ${actividad.diasRecordatorio} día(s) antes  ${actividad.horaRecordatorio}   - - - - -",
                                color = Color.Black,
                                fontSize = 13.sp,
                                modifier = Modifier.align(Alignment.CenterHorizontally))
                        } else {
                            DialogoEditar(
                                actividad = actividad,
                                cancelaAccion = { mostrandoEditar = false },
                                aceptaAction = { actividadEditada ->
                                    onEditar(actividad.key!!, actividadEditada) // Usar función modificar
                                    mostrandoEditar = false
                                    mostrarDialogo = false
                                }
                            )
                        }
                        Row(modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 17.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (!mostrandoEditar) {IconButton(onClick = { mostrandoEditar = true }) {
                                Icon(
                                    imageVector = Icons.Outlined.Edit,
                                    contentDescription = "Editar actividad",
                                    tint = Color(0xFF5E5E5E)
                                )
                            }
                            Spacer(modifier = Modifier.width(40.dp))
                            IconButton(onClick = { onEliminar() }) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = "Eliminar actividad",
                                    tint = Color(0xFF5E5E5E)
                                )
                            }
                        }
                        }
                    }
                }
            }
        }
    }
}

//Dialogo
@Composable
fun DialogoEliminar(curso: String, descripcion: String, cancelaAccion: () -> Unit, aceptaAction: () -> Unit) {
    AlertDialog(
        title = { Text(text = "¿Desea eliminar esta Actividad?") },
        text = {
            Column {
                Text(
                    buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(descripcion)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Curso: $curso")
            }
        },
        onDismissRequest = { cancelaAccion() },
        confirmButton = {
            TextButton(onClick = { aceptaAction() }, modifier = Modifier.height(31.dp)) {
                Text(text = "Eliminar actividad", color = Color(0xFFD00000))
            }
        },
        dismissButton = {
            TextButton(onClick = { cancelaAccion() }, modifier = Modifier.height(31.dp)) {
                Text(text = "Cancelar", color = Color(0xFFD00000))
            }
        },
        modifier = Modifier.height(227.dp)
    )
}


@Composable
fun DialogoEditar(
    actividad: Actividades,
    cancelaAccion: () -> Unit,
    aceptaAction: (Actividades) -> Unit
) {
    // Variables de Estado
    var curso by remember { mutableStateOf(actividad.curso) }
    var descripcion by remember { mutableStateOf(actividad.descripcion) }
    var fecha by remember { mutableStateOf(actividad.fechaentrega) }
    var hora by remember { mutableStateOf(actividad.horaentrega) }
    var diasRecordatorio by remember { mutableStateOf(actividad.diasRecordatorio) }
    var horaRecordatorio by remember { mutableStateOf(actividad.horaRecordatorio) }

    // Estados para los errores de validación
    var isFechaError by remember { mutableStateOf(false) }
    var isHoraError by remember { mutableStateOf(false) }

    var mostrarConfiguracion by remember { mutableStateOf(false) }
    val validarletras = remember { Regex("[A-Za-záéíóúÁÉÍÓÚüÜñÑ\\s]*") }
    val contexto = LocalContext.current

    if (mostrarConfiguracion) {
        ConfiguracionUI(
            onDismiss = { mostrarConfiguracion = false },
            onAccept = { diasSeleccionados, horaSeleccionada ->
                diasRecordatorio = diasSeleccionados
                horaRecordatorio = horaSeleccionada
                mostrarConfiguracion = false
            }
        )
    } else {
    Column(
        modifier = Modifier
            .fillMaxSize().padding(start = 25.dp, end = 25.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Editar Actividad",
                fontSize = 20.sp,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )
            IconButton(onClick = { mostrarConfiguracion = true}) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Settings Icon",
                    modifier = Modifier.size(23.dp)
                )
            }

        }
        CajaTextoGenerica(
            texto = curso,
            label = "Curso",
            onvalue = { if (it.matches(validarletras)) curso = it  },
            icon = { Icon(Icons.Default.Book, contentDescription = "Curso Icon") }
        )
        Spacer(modifier = Modifier.height(10.dp))
        CajaTextoGenerica(
            texto = descripcion,
            label = "Descripción",
            onvalue = { descripcion = it },
            icon = { Icon(Icons.Default.Description, contentDescription = "Descripción Icon") }
        )
        Spacer(modifier = Modifier.height(10.dp))
        CajaTextoGenericaFechaHora(
            texto = fecha,
            label = "Fecha Entrega",
            onValueChange = {
                fecha = it
                isFechaError = !isValidDate(it) && it.isNotBlank()
            },
            isDateField = true,
            isError = isFechaError,
            icon = { Icon(Icons.Default.DateRange, contentDescription = "Fecha Icon") }
        )
        Spacer(modifier = Modifier.height(10.dp))
        CajaTextoGenericaFechaHora(
            texto = hora,
            label = "Hora Entrega",
            onValueChange = {
                hora = it
                isHoraError = !isValidTime(it) && it.isNotBlank()
            },
            isError = isHoraError,
            icon = { Icon(Icons.Default.AccessTime, contentDescription = "Hora Icon") }
        )
        Row(
            modifier = Modifier.padding(top = 7.dp),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = { cancelaAccion() }) {
                Text(text = "Cancelar", color = Color(0xFFD00000))
            }
            Spacer(modifier = Modifier.width(45.dp))
            TextButton(onClick = {
                if (!isFechaError && !isHoraError) {
                    val recordatorioModificado = diasRecordatorio != actividad.diasRecordatorio ||
                            horaRecordatorio != actividad.horaRecordatorio

                    val objActividad = actividad.copy(
                        curso = curso,
                        descripcion = descripcion,
                        fechaentrega = fecha,
                        horaentrega = hora,
                        diasRecordatorio = if (recordatorioModificado) diasRecordatorio else actividad.diasRecordatorio,
                        horaRecordatorio = if (recordatorioModificado) horaRecordatorio else actividad.horaRecordatorio
                    )

                    aceptaAction(objActividad)

                    if (recordatorioModificado) {
                        programarNotificacion(contexto, objActividad)
                    }
                }
            }) {
                Text(text = "Aceptar", color = Color(0xFFD00000))
                }
            }
        }
    }
}

@Composable
fun RadioButtonGenerico(texto: String, seleccion: Boolean, onclick: () -> Unit) {
    RadioButton(selected = seleccion, onClick = onclick)
    Text(text=texto)
}

@Composable
fun DatePickerTextField() {
    var selectedDate by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Obtener la fecha actual
    val calendar = Calendar.getInstance()
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)

    // Crear DatePickerDialog
    val datePickerDialog = DatePickerDialog(
        context,
        { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            selectedDate = "$dayOfMonth/${month + 1}/$year"  // Actualiza la fecha seleccionada
        }, year, month, day
    )

    Column(modifier = Modifier.padding(16.dp)) {
        // Campo de texto para la fecha seleccionada
        OutlinedTextField(
            value = selectedDate,
            onValueChange = {},
            /*modifier = Modifier
                .clickable {
                    datePickerDialog.show()
                },*/
            trailingIcon = {
                IconButton(onClick = { datePickerDialog.show() }) {

                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = Icons.Default.CalendarMonth.name
                    )
                }

            },
            label = { Text("Selecciona una fecha") },
            enabled = false, // Deshabilitado para que solo se pueda modificar mediante el DatePicker
            colors = OutlinedTextFieldDefaults.colors(
                disabledTextColor = Color.Black, // Color azul para el texto cuando está deshabilitado
                disabledBorderColor = Color.Blue, // Color azul para el borde cuando está deshabilitado
                disabledLabelColor = Color.Blue, // Color azul para el label cuando está deshabilitado
                disabledTrailingIconColor = Color.Blue, // Color azul para el ícono cuando está deshabilitado
            )
         )
    }
}