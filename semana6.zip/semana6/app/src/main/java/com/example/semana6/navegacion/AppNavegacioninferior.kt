package com.example.semana6.navegacion

import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavHostController
import com.example.semana6.views.CalendarioUI
import com.example.semana6.views.ListadosUI
import java.time.LocalDate

@Composable
fun AppNavegacionInferior(navcontrolador: NavHostController) {
    // Mantener el día seleccionado usando rememberSaveable
    var diaSeleccionado by rememberSaveable { mutableStateOf(LocalDate.now().dayOfMonth) }

    NavHost(navController = navcontrolador, startDestination = ElementosNav.Calendario.ruta) {
        composable(route = ElementosNav.Calendario.ruta) {
            // Pasar diaSeleccionado a CalendarioUI y actualizarlo cuando cambie
            CalendarioUI(diaSeleccionado = diaSeleccionado, onDiaSeleccionadoChange = { nuevoDia ->
                diaSeleccionado = nuevoDia
            })
        }
        composable(route = ElementosNav.Listado.ruta) {
            // Invocar la UI Listados
            ListadosUI()
        }
    }
}
