package com.example.semana6.views

import android.widget.CalendarView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.semana6.AccesoFireBase.ManejadorRT
import com.example.semana6.componentesUI.DialogoEditar
import com.example.semana6.componentesUI.DialogoEliminar
import com.example.semana6.componentesUI.ItemActividades
import com.example.semana6.logicaNegocio.Actividades
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.rememberPagerState
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarioUI(
    diaSeleccionado: Int,
    onDiaSeleccionadoChange: (Int) -> Unit
) {
    val contexto = LocalContext.current
    val realtime = ManejadorRT(contexto)
    val listaActividades by realtime.obtenerlistaactividades().collectAsState(emptyList())

    val formatoFecha = DateTimeFormatter.ofPattern("d/M/yyyy")
    val fechaActual = LocalDate.now()
    var abrirDialogoEditar by remember { mutableStateOf(false) }
    var abrirDialogoEliminar by remember { mutableStateOf(false) }
    var seleccionActividad by remember { mutableStateOf<Actividades?>(null) }
    var fechaSeleccionada by remember { mutableStateOf(fechaActual) }

    if (abrirDialogoEditar && seleccionActividad != null) {
        DialogoEditar(
            actividad = seleccionActividad!!,
            cancelaAccion = { abrirDialogoEditar = false },
            aceptaAction = { actividadEditada ->
                seleccionActividad = actividadEditada.copy(key = seleccionActividad!!.key)
                realtime.modificarActividad(seleccionActividad!!.key!!, seleccionActividad!!)
                abrirDialogoEditar = false
            }
        )
    }

    if (abrirDialogoEliminar && seleccionActividad != null) {
        DialogoEliminar(
            curso = seleccionActividad!!.curso,
            descripcion = seleccionActividad!!.descripcion,
            cancelaAccion = { abrirDialogoEliminar = false }
        ) {
            realtime.eliminarActividad(seleccionActividad!!.key!!)
            abrirDialogoEliminar = false
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 16.dp, end = 16.dp)
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            AndroidView(
                factory = { context ->
                    CalendarView(context).apply {
                        setOnDateChangeListener { _, year, month, dayOfMonth ->
                            val nuevaFecha = LocalDate.of(year, month + 1, dayOfMonth)
                            fechaSeleccionada = nuevaFecha
                            onDiaSeleccionadoChange(nuevaFecha.dayOfMonth)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(330.dp)
                    .padding(bottom = 30.dp),
                update = { calendarView ->
                    val millis = fechaSeleccionada
                        .atStartOfDay(ZoneId.systemDefault())
                        .toInstant()
                        .toEpochMilli()
                    calendarView.date = millis
                }
            )
        }

        val actividadesDelDia = listaActividades.filter {
            it.fechaentrega == fechaSeleccionada.format(formatoFecha)
        }

        if (actividadesDelDia.isEmpty()) {
            item {
                Text(
                    text = "No hay actividades para esta fecha",
                    style = MaterialTheme.typography.h6,
                    color = Color.Gray,  fontSize = 16.sp
                )
            }
        } else {
            items(actividadesDelDia) { actividad ->
                ItemActividades(
                    actividad = actividad,
                    onEditar = { key, actividadEditada ->
                        realtime.modificarActividad(key, actividadEditada)
                    },
                    onEliminar = {
                        seleccionActividad = actividad
                        abrirDialogoEliminar = true
                    }
                )
            }
        }
    }
}
