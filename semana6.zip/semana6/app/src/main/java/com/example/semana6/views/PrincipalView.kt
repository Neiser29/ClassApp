package com.example.semana6.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.rememberNavController
import com.example.semana6.componentesUI.NavegacionInferior
import com.example.semana6.componentesUI.TopBarra
import com.example.semana6.navegacion.AppNavegacionInferior

@Composable
fun PrincipalUI() {
    val navcontrolador = rememberNavController()
    Scaffold(
        topBar = {
            TopBarra(
                titulo = "ClassApp",
                colorBarra = Color(0xFFFFFFFF),
                navController = navcontrolador
            )
        },
        bottomBar = { NavegacionInferior(navcontrolador = navcontrolador, colorBarraInferior = Color(0xFFFFFFFF)) }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).background(Color.White)) {
            AppNavegacionInferior(navcontrolador = navcontrolador)
        }
    }
}
