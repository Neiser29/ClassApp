package com.example.semana6.modeloNav

enum class RutasNav {
    Principal,
    Registros,
    Calendario,
    Listados
}