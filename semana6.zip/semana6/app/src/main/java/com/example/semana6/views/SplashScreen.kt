package com.example.semana6.views

import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*

import androidx.compose.material.LinearProgressIndicator
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.semana6.R

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    var scale by remember { mutableStateOf(0.5f) }
    val transitionDuration = 1500L

    LaunchedEffect(Unit) {
        val scaleAnim = Animatable(scale)
        scaleAnim.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = transitionDuration.toInt(), easing = FastOutSlowInEasing)
        ) {
            scale = value
        }
        Handler(Looper.getMainLooper()).postDelayed({
            onTimeout()
        }, transitionDuration)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFEFEFE))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(top = 300.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.splash),
                contentDescription = "Logo",
                modifier = Modifier
                    .size(140.dp * scale)
            )
        }
        Image(
            painter = painterResource(id = R.drawable.sanjuan),
            contentDescription = "Imagen inferior",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(130.dp * scale)
                .padding(bottom = 16.dp)
        )
    }
}

@Preview
@Composable
fun SplashScreenPreview() {
    SplashScreen {}
}