package com.example.semana6.logicaNegocio

data class Actividades(
    var key: String? = null,
    var curso: String = "",
    var descripcion: String = "",
    var fechaentrega: String = "",
    var horaentrega: String = "",
    var diasRecordatorio: Int = 0,
    var horaRecordatorio: String = ""
)
