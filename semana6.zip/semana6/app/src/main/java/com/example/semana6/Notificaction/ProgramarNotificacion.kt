package com.example.semana6.Notificaction

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.semana6.logicaNegocio.Actividades
import java.text.SimpleDateFormat
import java.util.*

fun programarNotificacion(context: Context, actividad: Actividades) {
    val intent = Intent(context, NotificationReceiver::class.java).apply {
        putExtra("titulo", "Entrega: ${actividad.descripcion} - ${actividad.curso}")
        putExtra("mensaje", "Fecha límite: ${actividad.fechaentrega}   Hora: ${actividad.horaentrega}")
    }
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val calendar = Calendar.getInstance().apply {
        val fechaPartes = actividad.fechaentrega.split("/")
        set(Calendar.YEAR, fechaPartes[2].toInt())
        set(Calendar.MONTH, fechaPartes[1].toInt() - 1)
        set(Calendar.DAY_OF_MONTH, fechaPartes[0].toInt())

        val horaRecordatorio = actividad.horaRecordatorio.trim()
        val horaPartes = horaRecordatorio.split(" ")

        if (horaPartes.size < 2) {
            Log.e("Notificacion", "Formato de hora inválido: $horaRecordatorio")
            return
        }

        val horaMinutoPartes = horaPartes[0].split(":")
        val hora = horaMinutoPartes[0].toInt()
        val minutos = horaMinutoPartes[1].toInt()
        val amPm = horaPartes[1]

        if (amPm == "PM" && hora != 12) {
            set(Calendar.HOUR_OF_DAY, hora + 12)
        } else if (amPm == "AM" && hora == 12) {
            set(Calendar.HOUR_OF_DAY, 0)
        } else {
            set(Calendar.HOUR_OF_DAY, hora)
        }

        set(Calendar.MINUTE, minutos)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)

        add(Calendar.DAY_OF_MONTH, -actividad.diasRecordatorio)
    }

    val pendingIntent = PendingIntent.getBroadcast(
        context,
        actividad.hashCode(),
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    alarmManager.setExactAndAllowWhileIdle(
        AlarmManager.RTC_WAKEUP,
        calendar.timeInMillis,
        pendingIntent
    )
}
