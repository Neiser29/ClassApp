package com.example.semana6.views

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.semana6.componentesUI.CajaTextoGenericaFechaHora
import com.example.semana6.componentesUI.RadioButtonGenerico

@Composable
fun ConfiguracionUI(onDismiss: () -> Unit, onAccept: (Int, String) -> Unit) {
    var selectedOption by remember { mutableStateOf("1 día antes") }
    var personalizadoDias by remember { mutableStateOf(1) }
    var selectedHour by remember { mutableStateOf("") }

    val options = listOf("1 día antes", "3 días antes", "Personalizado")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp),
    ) {
        Text(
            text = "Tiempo de recordatorio",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            fontSize = 17.sp,
            modifier = Modifier.padding(start = 13.dp, top = 13.dp,bottom = 10.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            options.subList(0, 2).forEach { option ->
                Row(
                    modifier = Modifier
                        .weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButtonGenerico(
                        texto = option,
                        seleccion = (option == selectedOption),
                        onclick = { selectedOption = option }
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButtonGenerico(
                texto = options[2],
                seleccion = (options[2] == selectedOption),
                onclick = { selectedOption = options[2] }
            )

            if (selectedOption == "Personalizado") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .padding(start = 27.dp)
                        .fillMaxWidth()
                ) {
                    IconButton(
                        onClick = { if (personalizadoDias > 1) personalizadoDias-- },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Disminuir días",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = "$personalizadoDias día(s)",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                        onClick = { if (personalizadoDias < 15) personalizadoDias++ },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Aumentar días",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        Text(
            text = "Hora de recordatorio",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            fontSize = 17.sp,
            modifier = Modifier.padding(start = 13.dp, top = 25.dp, bottom = 20.dp)
        )

        Box(modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp)) {
            CajaTextoGenericaFechaHora(
                texto = selectedHour,
                label = "Seleccionar hora",
                onValueChange = { selectedHour = it },
                isDateField = false
            )
        }

        Spacer(modifier = Modifier.height(25.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Row(
            ) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                ) {
                    Text("Cancelar")
                }
                Spacer(modifier = Modifier.width(50.dp))
                Button(
                    onClick = {
                        val diasantes = if (selectedOption == "Personalizado") personalizadoDias else when (selectedOption) {
                            "1 día antes" -> 1
                            "3 días antes" -> 3
                            else -> 0
                        }
                        onAccept(diasantes, selectedHour)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE32D2D))
                ) {
                    Text("Aceptar")
                }
            }
        }
    }
}
