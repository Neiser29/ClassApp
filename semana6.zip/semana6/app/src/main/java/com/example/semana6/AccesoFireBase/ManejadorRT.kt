package com.example.semana6.AccesoFireBase

import com.example.semana6.logicaNegocio.Actividades
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class ManejadorRT {
    private val dbRT=FirebaseDatabase.getInstance().reference.child("Actividades")
    //Agregar Persona
    fun agregarActividad(actividad:Actividades){
        val llave=dbRT.push().key
        if (llave!=null){
            dbRT.child(llave).setValue(actividad)
        }
    }
    //Obtener Lista de Actividades
    fun obtenerlistaactividades():Flow<List<Actividades>> {
        val flujo= callbackFlow {
            val listener=dbRT.addValueEventListener(
                object: ValueEventListener{
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val lista = snapshot.children.mapNotNull {
                            ele->
                            val persona=ele.getValue(Actividades::class.java)
                            ele.key?.let { persona?.copy(key = it) }
                        }
                        trySend(lista).isSuccess
                    }

                    override fun onCancelled(error: DatabaseError) {
                        close(error.toException())
                    }
                }
            )
            awaitClose{dbRT.removeEventListener(listener)}
        }
        return flujo
    }
    // Modificar una actividad
    fun modificarActividad(key:String ,actividad: Actividades) {
            dbRT.child(key).setValue(actividad)
    }

    // Eliminar una actividad
    fun eliminarActividad(key: String) {
        dbRT.child(key).removeValue()
    }
}
