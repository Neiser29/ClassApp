package com.example.semana6.AccesoFireBase

import android.content.Context
import com.example.semana6.logicaNegocio.Actividades
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import android.provider.Settings


class ManejadorRT(context: Context) {
    private val deviceId = Settings.Secure.getString(
        context.contentResolver, Settings.Secure.ANDROID_ID
    )
    private val dbRT=FirebaseDatabase.getInstance().reference.child("Actividades")

    //Agregar Persona
    fun agregarActividad(actividad: Actividades) {
        val llave = dbRT.child(deviceId).push().key  // Usar el deviceId como nodo
        if (llave != null) {
            dbRT.child(deviceId).child(llave).setValue(actividad)  // Guardar bajo el deviceId
        }
    }

    //Obtener Lista de Actividades
    fun obtenerlistaactividades(): Flow<List<Actividades>> {
        val flujo = callbackFlow {
            val listener = dbRT.child(deviceId).addValueEventListener(
                object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val lista = snapshot.children.mapNotNull { ele ->
                            val persona = ele.getValue(Actividades::class.java)
                            ele.key?.let { persona?.copy(key = it) }
                        }
                        trySend(lista).isSuccess
                    }

                    override fun onCancelled(error: DatabaseError) {
                        close(error.toException())
                    }
                }
            )
            awaitClose { dbRT.removeEventListener(listener) }
        }
        return flujo
    }

    // Modificar una actividad
    fun modificarActividad(key: String, actividad: Actividades) {
        dbRT.child(deviceId).child(key).setValue(actividad)
    }

    // Eliminar una actividad
    fun eliminarActividad(key: String) {
        dbRT.child(deviceId).child(key).removeValue()
    }
}
