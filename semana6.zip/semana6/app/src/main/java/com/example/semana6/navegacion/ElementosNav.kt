package com.example.semana6.navegacion

import com.example.semana6.modeloNav.RutasNav

sealed class ElementosNav (val ruta:String){
    object Calendario:ElementosNav(RutasNav.Calendario.name)
    object Registro:ElementosNav(RutasNav.Registros.name)
    object Listado:ElementosNav(RutasNav.Listados.name)
}