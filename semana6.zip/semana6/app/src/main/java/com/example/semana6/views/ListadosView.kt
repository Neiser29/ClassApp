package com.example.semana6.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.DropdownMenu
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.semana6.AccesoFireBase.ManejadorRT
import com.example.semana6.componentesUI.DialogoEditar
import com.example.semana6.componentesUI.DialogoEliminar
import com.example.semana6.componentesUI.ItemActividades
import com.example.semana6.logicaNegocio.Actividades

@Composable
fun ListadosUI() {
    val contexto = LocalContext.current
    val realtime = ManejadorRT()
    val listaActividades by realtime.obtenerlistaactividades().collectAsState(emptyList())

    var abrirDialogoEditar by remember { mutableStateOf(false) }
    var abrirDialogoEliminar by remember { mutableStateOf(false) }
    var seleccionActividad by remember { mutableStateOf<Actividades?>(null) }
    var query by remember { mutableStateOf("") }
    var filtroSeleccionado by remember { mutableStateOf("Curso") }
    var mostrarMenuFiltro by remember { mutableStateOf(false) }

    val listaFiltrada = remember(query, filtroSeleccionado, listaActividades) {
        listaActividades.filter {
            when (filtroSeleccionado) {
                "Curso" -> it.curso.startsWith(query, ignoreCase = true)
                "Descripción" -> it.descripcion.startsWith(query, ignoreCase = true)
                "Fecha de entrega" -> it.fechaentrega.startsWith(query, ignoreCase = true)
                else -> false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 2.dp, start = 16.dp, end = 16.dp)
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (abrirDialogoEditar && seleccionActividad != null) {
            DialogoEditar(
                actividad = seleccionActividad!!,
                cancelaAccion = { abrirDialogoEditar = false },
                aceptaAction = { actividadEditada ->
                    seleccionActividad = actividadEditada.copy(key = seleccionActividad!!.key)
                    realtime.modificarActividad(seleccionActividad!!.key!!, seleccionActividad!!)
                    abrirDialogoEditar = false
                }
            )
        }

        if (abrirDialogoEliminar && seleccionActividad != null) {
            DialogoEliminar(
                curso = seleccionActividad!!.curso,
                descripcion = seleccionActividad!!.descripcion,
                cancelaAccion = { abrirDialogoEliminar = false },
                aceptaAction = {
                    seleccionActividad?.key?.let { key ->
                        realtime.eliminarActividad(key)
                    }
                    abrirDialogoEliminar = false
                }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 21.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(value = query, onValueChange = { query = it }, placeholder = {
                    Text(text = "Buscar", style = TextStyle(color = Color.Gray, fontSize = 16.sp))
                }, modifier = Modifier.width(365.dp).height(50.dp).padding(start = 3.dp, end = 3.dp).clip(RoundedCornerShape(25.dp)),
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = { mostrarMenuFiltro = !mostrarMenuFiltro }) { Icon(Icons.Outlined.FilterList, contentDescription = "Filtrar")
                    }
                },
                colors = TextFieldDefaults.textFieldColors(
                    backgroundColor = Color(0xFFF3F3F3),
                    focusedLabelColor = Color.Gray,
                    unfocusedLabelColor = Color.Gray,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color(0xFFD62121)
                ),
                textStyle = TextStyle(color = Color.Gray)
            )
            Box(
                modifier = Modifier.wrapContentSize(Alignment.CenterEnd)
            ) {
                DropdownMenu(
                    expanded = mostrarMenuFiltro,
                    onDismissRequest = { mostrarMenuFiltro = false },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    DropdownMenuItem(onClick = { filtroSeleccionado = "Curso"; mostrarMenuFiltro = false }) {
                        Text("Curso")
                    }
                    DropdownMenuItem(onClick = { filtroSeleccionado = "Descripción"; mostrarMenuFiltro = false }) {
                        Text("Descripción")
                    }
                    DropdownMenuItem(onClick = { filtroSeleccionado = "Fecha de entrega"; mostrarMenuFiltro = false }) {
                        Text("Fecha de Entrega")
                    }
                }
            }
        }

        LazyColumn {
            items(listaFiltrada,key = { it.key?: it.hashCode() }) { actividad ->
                ItemActividades(
                    actividad = actividad,
                    onEditar = { key, actividadEditada ->
                        realtime.modificarActividad(key, actividadEditada)
                    },
                    onEliminar = {
                        seleccionActividad = actividad
                        abrirDialogoEliminar = true
                    }
                )
            }
        }
    }
}
