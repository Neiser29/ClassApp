package com.example.semana6

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.tooling.preview.Preview
import com.example.semana6.ui.theme.Semana6Theme
import com.example.semana6.views.PrincipalUI
import com.example.semana6.views.SplashScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            Semana6Theme {
                var isSplashScreenVisible by remember { mutableStateOf(true) }

                if (isSplashScreenVisible) {
                    SplashScreen {
                        isSplashScreenVisible = false
                    }
                } else {
                    PrincipalUI()
                }
            }
        }
    }
}
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Semana6Theme {
    }
}
