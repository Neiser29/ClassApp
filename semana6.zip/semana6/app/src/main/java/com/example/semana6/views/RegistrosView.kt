package com.example.semana6.views

import android.view.Gravity
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.semana6.AccesoFireBase.ManejadorRT
import com.example.semana6.Notificaction.programarNotificacion
import com.example.semana6.R
import com.example.semana6.componentesUI.BotonGenerico
import com.example.semana6.componentesUI.CajaTextoGenerica
import com.example.semana6.componentesUI.CajaTextoGenericaFechaHora
import com.example.semana6.componentesUI.isValidDate
import com.example.semana6.componentesUI.isValidTime
import com.example.semana6.logicaNegocio.Actividades

@Composable
fun RegistrosUI(navcontrolador: NavController) {

    val contexto = LocalContext.current

    val realTime = ManejadorRT(contexto)

    var isConfigScreen by remember { mutableStateOf(false) }
    var diasantes by remember { mutableStateOf(1) }
    var selectedHour by remember { mutableStateOf("") }

    var curso by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf("") }
    var hora by remember { mutableStateOf("") }
    var isFechaError by remember { mutableStateOf(false) }
    var isHoraError by remember { mutableStateOf(false) }

    var isActividadConConfiguracion by remember { mutableStateOf(false) }

    val validarletras = remember { Regex("[A-Za-záéíóúÁÉÍÓÚüÜñÑ\\s]*") }

    if (isConfigScreen) {
        ConfiguracionUI(
            onDismiss = { isConfigScreen = false },
            onAccept = { diasSeleccionados, horaSeleccionada ->
                diasantes = diasSeleccionados
                selectedHour = horaSeleccionada
                isActividadConConfiguracion = true
                isConfigScreen = false
            }
        )
    } else {
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 40.dp, end = 28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Registro de Actividad", modifier = Modifier.weight(1f), fontSize = 20.sp)
                IconButton(onClick = { isConfigScreen = true }) {
                    Icon(Icons.Outlined.Settings, contentDescription = "Configuración", modifier = Modifier.size(23.dp))
                }
            }

            CajaTextoGenerica(
                texto = curso,
                label = "Curso",
                onvalue = { if (it.matches(validarletras)) curso = it  },
                icon = { Icon(Icons.Outlined.Book, contentDescription = "") }
            )
            CajaTextoGenerica(
                texto = descripcion,
                label = "Descripción",
                onvalue = { descripcion = it },
                icon = { Icon(Icons.Outlined.Description, contentDescription = "") }
            )
            CajaTextoGenericaFechaHora(
                texto = fecha,
                label = "Fecha de Entrega",
                onValueChange = {
                    fecha = it
                    isFechaError = !isValidDate(it) && it.isNotBlank()
                },
                isDateField = true,
                isError = isFechaError,
            )
            CajaTextoGenericaFechaHora(
                texto = hora,
                label = "Hora de Entrega",
                onValueChange = {
                    hora = it
                    isHoraError = !isValidTime(it) && it.isNotBlank()
                },
                isDateField = false,
                isError = isHoraError,
            )

            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                BotonGenerico(texto = "Guardar") {
                    if (curso.isNotBlank() && descripcion.isNotBlank() && fecha.isNotBlank() && hora.isNotBlank() &&
                        !isFechaError && !isHoraError
                    ) {
                        if (isActividadConConfiguracion) {
                            val actividad = Actividades(
                                curso = curso,
                                descripcion = descripcion,
                                fechaentrega = fecha,
                                horaentrega = hora,
                                diasRecordatorio = diasantes,
                                horaRecordatorio = selectedHour
                            )
                            realTime.agregarActividad(actividad)

                            programarNotificacion(contexto, actividad)

                            curso = ""
                            descripcion = ""
                            fecha = ""
                            hora = ""
                            isActividadConConfiguracion = false
                        }
                        else {
                            val inflater = LayoutInflater.from(contexto)
                            val layout = inflater.inflate(R.layout.toast_layout, null)
                            val toastText: TextView = layout.findViewById(R.id.toast_text)
                            toastText.text = "Complete la configuración"
                            val toast = Toast(contexto)
                            toast.duration = Toast.LENGTH_SHORT
                            toast.view = layout
                            toast.setGravity(Gravity.BOTTOM, 0, 8)
                            toast.show()
                        }
                    } else {
                        val inflater = LayoutInflater.from(contexto)
                        val layout = inflater.inflate(R.layout.toast_layout, null)
                        val toastText: TextView = layout.findViewById(R.id.toast_text)
                        toastText.text = "Complete los datos correctamente"
                        val toast = Toast(contexto)
                        toast.duration = Toast.LENGTH_SHORT
                        toast.view = layout
                        toast.setGravity(Gravity.BOTTOM, 0, 8)
                        toast.show()
                    }
                }
            }
        }
    }
}
