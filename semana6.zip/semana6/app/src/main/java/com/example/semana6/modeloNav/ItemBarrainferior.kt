package com.example.semana6.modeloNav


import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddTask
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.semana6.navegacion.ElementosNav

sealed class ItemBarrainferior (val icono: ImageVector, val titulo:String, val ruta:String){
    object ItemCalendario:ItemBarrainferior(Icons.Outlined.CalendarMonth,"Calendario", ElementosNav.Calendario.ruta)
    object ItemListado:ItemBarrainferior(Icons.Outlined.Checklist,"Listado", ElementosNav.Listado.ruta)
}